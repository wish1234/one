package initial

import (
	"opms/utils"
)

func InitCache() {
	utils.InitCache()
}
