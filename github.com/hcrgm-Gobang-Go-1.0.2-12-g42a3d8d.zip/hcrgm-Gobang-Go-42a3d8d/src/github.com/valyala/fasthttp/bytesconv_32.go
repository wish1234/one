// +build !amd64,!arm64,!ppc64

package fasthttp

const (
	maxIntChars    = 9
	maxHexIntChars = 7
)
