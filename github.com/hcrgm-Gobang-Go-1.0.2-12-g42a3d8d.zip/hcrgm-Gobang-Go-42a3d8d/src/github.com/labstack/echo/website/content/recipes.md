+++
title = "Recipes"
description = "Recipes"
type = "recipes"
[menu.main]
  name = "Recipes"
  pre = "<i class='fa fa-code'></i>"
  weight = 2
  identifier = "recipes"
  url = "/recipes"
+++

<script>location = "/recipes/hello-world";</script>
