+++
title = "Subdomains Example"
description = "Subdomains example for Echo"
[menu.main]
  name = "Subdomains"
  parent = "recipes"
  weight = 10
+++

`server.go`

{{< embed "subdomains/server.go" >}}

## [Source Code]({{< source "subdomains" >}})

## Maintainers

- [axdg](https://github.com/axdg)
- [vishr](https://github.com/vishr)
