# cpuid private

This is a specially converted of the cpuid package, so it can be included in
a package without exporting anything.

Package home: https://github.com/klauspost/cpuid
